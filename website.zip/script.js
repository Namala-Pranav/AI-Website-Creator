document.addEventListener('DOMContentLoaded', () => {
    const sendButton = document.getElementById('send-button');
    const userInput = document.getElementById('user-input');
    const messageHistory = document.getElementById('message-history');
    const temperatureSlider = document.getElementById('temperature');
    const temperatureValueSpan = document.getElementById('temperature-value');

    // Update temperature value display
    temperatureSlider.addEventListener('input', () => {
        temperatureValueSpan.textContent = temperatureSlider.value;
    });

    // Auto-resize textarea
    userInput.addEventListener('input', () => {
        userInput.style.height = 'auto';
        userInput.style.height = userInput.scrollHeight + 'px';
    });

    // Send message on button click
    sendButton.addEventListener('click', sendMessage);

    // Send message on Enter key press (without Shift)
    userInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault(); // Prevent new line in textarea
            sendMessage();
        }
    });

    function sendMessage() {
        const messageText = userInput.value.trim();
        if (messageText === '') return;

        // Add user message to history
        const userMessageDiv = document.createElement('div');
        userMessageDiv.classList.add('message', 'user-message');
        userMessageDiv.innerHTML = `<p>${messageText}</p>`;
        messageHistory.appendChild(userMessageDiv);

        userInput.value = ''; // Clear input
        userInput.style.height = 'auto'; // Reset textarea height

        // Scroll to the bottom immediately after user message
        scrollToBottom();

        // Simulate AI response after a short delay
        setTimeout(() => {
            const aiMessageDiv = document.createElement('div');
            aiMessageDiv.classList.add('message', 'ai-message');
            aiMessageDiv.innerHTML = `<p>This is a simulated AI response to "${messageText}".</p>`;
            messageHistory.appendChild(aiMessageDiv);
            scrollToBottom(); // Scroll to bottom again after AI message
        }, 800); // Simulate network latency
    }

    function scrollToBottom() {
        messageHistory.scrollTop = messageHistory.scrollHeight;
    }

    // Initial scroll to bottom if there are messages
    scrollToBottom();
});